#Nombre Xavier Jaramillo
#1. Realice una calculadora que convierta números binarios a decimales y guarde la
#salida y su nombre en un archivo de texto. La entrada se tomará de otro archivo
#de texto.
from builtins import print

def leertxtenlista():
    archi=open('binario.txt','r')
    lineas=archi.readlines()
    print(lineas)
    print("El decimal es :")
    return int(str(lineas[0]), 2)
    archi.close()
resultado = leertxtenlista()
print(resultado)

def creartxt():
    archi=open('decimal.txt','w')
    archi.close()

def grabartxt():
    archi=open('decimal.txt','a')
    archi.write('El numero en decimal es:'+resultado)
    archi.close()

leertxtenlista()
creartxt()
grabartxt()
