#Nombre Xavier Jaramillo
#3. Realice un codificador de mensajes

tabla = [['T', 'R','W','A','G','M','Y','F','P','D','X',
'B','N','J','Z','S','Q','V','H','L','C','K','E'],[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]]


def leertxtenlista():
    archi = open('MensajeAcodificar.txt', 'r')
    lineas = archi.readlines()
    print(lineas)
    archi.close()

def decifrarMensaje():
    print(tabla[0])


def creartxt():
    archi = open('MensajeCodificado.txt', 'w')
    archi.close()

def grabartxt():
    archi = open('MensajeCodificado.txt', 'a')
    archi.write("El mensaje codificado es :" )
    archi.close()

leertxtenlista()
creartxt()
grabartxt()