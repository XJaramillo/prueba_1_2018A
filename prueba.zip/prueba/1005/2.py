# Nombre Xavier Jaramillo
# 2. Invierta el contenido de una cadena de texto y guárdelo en un archivo de texto.

def leertxtenlista():
    archi = open('cadenaNormal.txt', 'r')
    lineas = archi.readlines()
    print(lineas)

    def reverse(lineas):
        if len(lineas) == 1:
            return lineas
        else:
            return lineas[-1] + reverse(lineas[:-1])
    print(reversed(lineas))

    archi.close()

def creartxt():
    archi = open('cadenaInvertida.txt', 'w')
    archi.close()

def grabartxt():
    archi = open('cadenaInvertida.txt', 'a')
    archi.write("Cadena Invertida es :" )
    archi.close()

leertxtenlista()
creartxt()
grabartxt()

